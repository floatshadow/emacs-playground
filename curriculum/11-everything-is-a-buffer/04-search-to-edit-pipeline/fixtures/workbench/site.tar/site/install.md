# Install

cargo build --release
