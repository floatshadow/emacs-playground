# tally

Welcome to teh tally site. tally counts numbers into buckets and
prints a histogram in the terminal.

- [Install](install.md)
- [Questions](faq.md)
